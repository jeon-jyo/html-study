const loginForm = document.querySelector("#login-form");
const loginInput = document.querySelector("#login-form input");
const greeting = document.querySelector("#greeting");

const USERNAME_KEY = "username";


const printGreeting = (username) => {
    greeting.innerText = `Hello ${username}`;
    greeting.classList.remove('hidden');
};

const onLoginSubmit = (event) => {
    event.preventDefault();
    const username = loginInput.value;
    loginInput.value = "";

    localStorage.setItem(USERNAME_KEY, username);
    printGreeting(username);
};

const savedUserName = localStorage.getItem(USERNAME_KEY);
if (savedUserName === null) {
    loginForm.addEventListener("submit", onLoginSubmit);
} else {
    printGreeting(savedUserName);
}



// Arrow Function;
// const foo = a => a;



